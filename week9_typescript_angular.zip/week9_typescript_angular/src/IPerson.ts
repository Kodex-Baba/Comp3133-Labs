export default interface IPerson {
    firstName: string;
    lastName: string;
    showInfo() : void
}

export var college_name = "Godolkan College"